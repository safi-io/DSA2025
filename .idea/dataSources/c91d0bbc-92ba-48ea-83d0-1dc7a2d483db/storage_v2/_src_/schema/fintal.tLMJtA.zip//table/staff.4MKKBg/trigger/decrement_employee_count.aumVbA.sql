create definer = root@localhost trigger DECREMENT_EMPLOYEE_COUNT
    after delete
    on staff
    for each row
BEGIN
	UPDATE BRANCH
	SET BRANCH_EMPLOYEE_COUNT = BRANCH_EMPLOYEE_COUNT -1
    WHERE BRANCH_ID = OLD.STAFF_BRANCH_ID;
END;

