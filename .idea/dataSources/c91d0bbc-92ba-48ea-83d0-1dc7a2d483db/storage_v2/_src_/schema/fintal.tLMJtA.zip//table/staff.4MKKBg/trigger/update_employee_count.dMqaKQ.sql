create definer = root@localhost trigger UPDATE_EMPLOYEE_COUNT
    after update
    on staff
    for each row
BEGIN
    -- Only update if the branch has actually changed
    IF OLD.STAFF_BRANCH_ID <> NEW.STAFF_BRANCH_ID THEN
        -- Decrease count from old branch
        UPDATE BRANCH
        SET BRANCH_EMPLOYEE_COUNT = BRANCH_EMPLOYEE_COUNT - 1
        WHERE BRANCH_ID = OLD.STAFF_BRANCH_ID;

        -- Increase count in new branch
        UPDATE BRANCH
        SET BRANCH_EMPLOYEE_COUNT = BRANCH_EMPLOYEE_COUNT + 1
        WHERE BRANCH_ID = NEW.STAFF_BRANCH_ID;
    END IF;
END;

